import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private _loginService:LoginService,private _router:Router) { }

  username='';
  password='';


  ngOnInit(): void {
  }

  onLogin=(loginForm:NgForm)=>{
    console.log(loginForm.value);
    this._loginService.login(this.username,this.password).subscribe({
      next:(data)=>console.log(data)
    }
    )

  }
}
