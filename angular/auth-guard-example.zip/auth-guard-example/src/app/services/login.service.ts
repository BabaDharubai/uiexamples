import { Injectable } from '@angular/core';
import { of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  //create a flag to check if the user is logged in
  private _isLoggedIn:boolean

  constructor() {
    this._isLoggedIn=false;
   }

   login=(username:string,password:string)=>{
    //check username and password by making an api call
    if(username=='Baba' && password=='baba'){
      //change the value of isLoggedIn
      this._isLoggedIn=true;
      //return an observable of true;
      return of(this._isLoggedIn);
    }
    //if not a valid user return an observable of false
    return of(this._isLoggedIn);
   }

   //use a method to check the value of loggedin user
   isUserLoggedIn=()=>{
    return this._isLoggedIn;
   }

   //create a logout method also
   logout=()=>{
    this._isLoggedIn=false;
   }
}
