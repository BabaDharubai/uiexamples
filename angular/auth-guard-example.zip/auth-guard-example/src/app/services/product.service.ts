import { Injectable } from '@angular/core';
import {of, Observable } from 'rxjs';
import { Product } from '../models/product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor() { }

  products:Product[]=[
    new Product(1,'watch',200000,'Rolex','watches'),
    new Product(2,'watch',3000,'Noise','watches'),
    new Product(3,'headphones',1500,'Realme','gadges'),
    new Product(4,'whisky smoke',500,'Beardo','perfumes'),
    new Product(5,'wild-stone',300,'WildStone','perfumes'),
    new Product(6,'shirt',1500,'Crocodile','clothes'),
    new Product(7,'trouser',1000,'Netplay','clothes')
  ]

  getProducts=():Observable<Product[]>=>{

    return of(this.products)
  }
}
