import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { LoginService } from '../services/login.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService implements CanActivate{

  constructor(private _loginService:LoginService,private _router:Router) { }
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    if(!this._loginService.isUserLoggedIn()){
      console.log("user is not logged in");

      //route the user to login page
      //route.url 
      http://localhost:4200/login?returnUrl=products
      this._router.navigate(["login"],{queryParams:{returnUrl:route.url}})

      return false;
    }
    return true;
  }
}
