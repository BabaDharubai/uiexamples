export class Product {

    constructor(
        public productId:number,
        public name:string,
        public price:number,
        public brand:string,
        public category:string
    ){}
}
